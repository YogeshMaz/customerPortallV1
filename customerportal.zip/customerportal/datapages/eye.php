<div class="dropdown hidecolumn">
    <a class="btn btn-primary btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
        <i class="fa fa-eye"></i>  
    </a>

    <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
        <li>
        <a class="dropdown-item d-none" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="0" checked> Project No</label>
        </a>
        </li>
        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="1" checked> Project No</label>
        </a>
        </li>
        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="2" checked> Customer PO</label>
        </a>
        </li>
        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="3" checked> Delivery Schedule Type</label>
        </a>
        </li>
        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="4" checked> Part Names</label>
        </a>
        </li>
        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="5" checked> Item Description / Item part No</label>
        </a>
        </li>
        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="6" checked> Quantity Shiped to Customer</label>
        </a>
        </li>
        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="7" checked> Customer Accepted Quantity</label>
        </a>
        </li>

        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="8" checked> Unit</label>
        </a>
        </li>
        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="9" checked> Planned Date of Delivery</label>
        </a>
        </li>
        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="10" checked> Actual Date of Delivery</label>
        </a>
        </li>
        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="11" checked> Quality Acceptance Rate Machinemaze</label>
        </a>
        </li>
        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="12" checked> Supply Quality Docs</label>
        </a>
        </li>
        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="13" checked> Shipping Document</label>
        </a>
        </li>
        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="14" checked> Tracking Number</label>
        </a>
        </li>
        <li>
        <a class="dropdown-item" href="#">
            <label><input type="checkbox" class="toggleColumn_d" data-column="15" checked> Delivery Address</label>
        </a>
        </li>

    </ul>
    </div>

    